// Fit Journal PWA – Daily Outfit Photos

const DB_NAME = 'FitJournalDB';
const STORE_NAME = 'fits';
const DB_VERSION = 1;

let db = null;

// ---------- IndexedDB ----------
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const database = e.target.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        database.createObjectStore(STORE_NAME, { keyPath: 'date' });
      }
    };
    request.onsuccess = (e) => {
      db = e.target.result;
      resolve(db);
    };
    request.onerror = () => reject(request.error);
  });
}

function saveFit(date, dataUrl) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put({ date, photo: dataUrl, timestamp: Date.now() });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function getFit(date) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(date);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function getAllFits() {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

// ---------- Helpers ----------
function todayKey() {
  const d = new Date();
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
}

function formatDate(iso) {
  const d = new Date(iso + 'T12:00:00');
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric'
  });
}

function formatFullDate(iso) {
  const d = new Date(iso + 'T12:00:00');
  return d.toLocaleDateString(undefined, {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

// Compress image to keep storage reasonable
function compressImage(file, maxWidth = 1080, quality = 0.75) {
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, width, height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.src = url;
  });
}

// ---------- UI ----------
const todayDateEl = document.getElementById('todayDate');
const todayPhotoContainer = document.getElementById('todayPhotoContainer');
const todayPhoto = document.getElementById('todayPhoto');
const captureArea = document.getElementById('captureArea');
const snapBtn = document.getElementById('snapBtn');
const cameraInput = document.getElementById('cameraInput');
const retakeBtn = document.getElementById('retakeBtn');
const pastFitsEl = document.getElementById('pastFits');
const emptyPast = document.getElementById('emptyPast');
const enableNotifBtn = document.getElementById('enableNotifBtn');
const notifStatus = document.getElementById('notifStatus');
const viewer = document.getElementById('viewer');
const viewerImg = document.getElementById('viewerImg');
const viewerDate = document.getElementById('viewerDate');
const closeViewer = document.getElementById('closeViewer');

function updateTodayUI(fit) {
  if (fit && fit.photo) {
    todayPhoto.src = fit.photo;
    todayPhotoContainer.classList.remove('hidden');
    captureArea.classList.add('hidden');
  } else {
    todayPhotoContainer.classList.add('hidden');
    captureArea.classList.remove('hidden');
  }
}

async function loadToday() {
  const key = todayKey();
  todayDateEl.textContent = formatFullDate(key);
  const fit = await getFit(key);
  updateTodayUI(fit);
}

async function loadPast() {
  const all = await getAllFits();
  const today = todayKey();
  const past = all
    .filter(f => f.date !== today)
    .sort((a, b) => b.date.localeCompare(a.date));

  pastFitsEl.innerHTML = '';
  if (past.length === 0) {
    emptyPast.classList.remove('hidden');
    return;
  }
  emptyPast.classList.add('hidden');

  past.forEach(fit => {
    const item = document.createElement('div');
    item.className = 'past-item';
    item.innerHTML = `
      <img src="${fit.photo}" alt="Fit on ${fit.date}" loading="lazy" />
      <div class="date-badge">${formatDate(fit.date)}</div>
    `;
    item.addEventListener('click', () => openViewer(fit));
    pastFitsEl.appendChild(item);
  });
}

function openViewer(fit) {
  viewerImg.src = fit.photo;
  viewerDate.textContent = formatFullDate(fit.date);
  viewer.classList.remove('hidden');
}

closeViewer.addEventListener('click', () => {
  viewer.classList.add('hidden');
});

// ---------- Camera ----------
snapBtn.addEventListener('click', () => {
  cameraInput.click();
});

retakeBtn.addEventListener('click', () => {
  cameraInput.click();
});

cameraInput.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  try {
    const dataUrl = await compressImage(file);
    const key = todayKey();
    await saveFit(key, dataUrl);
    updateTodayUI({ photo: dataUrl });
    await loadPast(); // in case we want to refresh
  } catch (err) {
    console.error(err);
    alert('Could not save photo. Please try again.');
  }
  cameraInput.value = '';
});

// ---------- Notifications ----------
async function checkNotificationStatus() {
  if (!('Notification' in window)) {
    notifStatus.textContent = 'Notifications not supported on this browser';
    enableNotifBtn.disabled = true;
    return;
  }

  if (Notification.permission === 'granted') {
    notifStatus.textContent = 'Reminders enabled ✓';
    enableNotifBtn.textContent = '🔔 Reminders On';
  } else if (Notification.permission === 'denied') {
    notifStatus.textContent = 'Permission denied. Enable in browser settings.';
  } else {
    notifStatus.textContent = 'Get a gentle nudge every day';
  }
}

enableNotifBtn.addEventListener('click', async () => {
  if (!('Notification' in window)) return;

  const permission = await Notification.requestPermission();
  if (permission === 'granted') {
    notifStatus.textContent = 'Reminders enabled ✓';
    enableNotifBtn.textContent = '🔔 Reminders On';

    // Show a confirmation notification
    new Notification('Fit Journal', {
      body: 'Daily reminders are on! Come back tomorrow to snap your fit.',
      icon: 'icon-192.png'
    });

    // Simple daily check when app is opened
    scheduleLocalReminder();
  } else {
    notifStatus.textContent = 'Permission denied. You can still use the app.';
  }
});

function scheduleLocalReminder() {
  // Note: True background daily push requires a server + push subscription.
  // This is a lightweight client-side reminder that fires if the app is open
  // or when the user returns the next day.
  const last = localStorage.getItem('lastNotifDate');
  const today = todayKey();
  if (last !== today && Notification.permission === 'granted') {
    // Will show next time they open the app if they haven't taken a photo
    localStorage.setItem('pendingReminder', '1');
  }
}

async function maybeShowReminder() {
  if (Notification.permission !== 'granted') return;
  const pending = localStorage.getItem('pendingReminder');
  const today = todayKey();
  const fit = await getFit(today);

  if (pending && !fit) {
    new Notification('Time for today’s fit 📸', {
      body: 'Open Fit Journal and snap your outfit of the day!',
      icon: 'icon-192.png'
    });
    localStorage.removeItem('pendingReminder');
    localStorage.setItem('lastNotifDate', today);
  }
}

// ---------- Service Worker ----------
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js')
    .then(() => console.log('SW registered'))
    .catch(err => console.log('SW failed', err));
}

// ---------- Init ----------
async function init() {
  try {
    await openDB();
    await loadToday();
    await loadPast();
    await checkNotificationStatus();
    await maybeShowReminder();
  } catch (err) {
    console.error('Init error', err);
  }
}

init();
